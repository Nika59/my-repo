﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace DOTNETFinal_khurtsidze
{
    public partial class Form1 : Form
    {
        private string connectionString;

        public Form1()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["DefaultConnection"].ConnectionString;
        }

        private void Read_Click(object sender, EventArgs e)
        {
            string query = "SELECT * FROM Marks";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    SqlCommand command = new SqlCommand(query, connection);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter(command);

                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("An error occurred while reading data: " + ex.Message);
                }
            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            if (int.TryParse(mark_id.Text, out int markId))
            {
                string query = "DELETE FROM Marks WHERE mark_id = @mark_id";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@mark_id", markId);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record deleted successfully.");
                        }
                        else
                        {
                            MessageBox.Show("No record found with the provided mark_id.");
                        }

                        Read_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while deleting data: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter a valid mark_id.");
            }
        }

        private void Create_Click(object sender, EventArgs e)
        {
            if (int.TryParse(mark_id.Text, out int markId) &&
                int.TryParse(student_id.Text, out int studentId) &&
                int.TryParse(subject_id.Text, out int subjectId) &&
                int.TryParse(mark.Text, out int markValue))
            {
                string query = "INSERT INTO Marks (mark_id, student_id, subject_id, date, mark) " +
                               "VALUES (@mark_id, @student_id, @subject_id, @date, @mark)";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@mark_id", markId);
                        command.Parameters.AddWithValue("@student_id", studentId);
                        command.Parameters.AddWithValue("@subject_id", subjectId);
                        command.Parameters.AddWithValue("@date", date.Text);
                        command.Parameters.AddWithValue("@mark", markValue);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record created successfully.");
                        }
                        else
                        {
                            MessageBox.Show("Record creation failed.");
                        }

                        Read_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while creating record: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integer values for mark_id, student_id, subject_id, and mark.");
            }
        }

        private void Update_Click(object sender, EventArgs e)
        {
            if (int.TryParse(mark_id.Text, out int markId) &&
                int.TryParse(mark.Text, out int markValue))
            {
                string query = "UPDATE Marks SET mark = @mark WHERE mark_id = @mark_id";

                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    try
                    {
                        connection.Open();

                        SqlCommand command = new SqlCommand(query, connection);
                        command.Parameters.AddWithValue("@mark_id", markId);
                        command.Parameters.AddWithValue("@mark", markValue);

                        int rowsAffected = command.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully.");
                        }
                        else
                        {
                            MessageBox.Show("No record found with the provided mark_id.");
                        }

                        Read_Click(sender, e);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while updating record: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please enter valid integer values for mark_id and mark.");
            }
        }

        private void create_procedure_Click(object sender, EventArgs e)
        {
            string procedureName = procedure_name.Text.Trim();
            if (string.IsNullOrEmpty(procedureName))
            {
                MessageBox.Show("Please enter a procedure name.");
                return;
            }

            string idParamName = "@id";
            string scoreParamName = "@score";
            string procedureQuery = $"CREATE PROCEDURE {procedureName} " +
                                    $"{idParamName} AS INT, {scoreParamName} AS INT " +
                                    "AS " +
                                    "BEGIN " +
                                    "UPDATE Marks " +
                                    "SET mark = mark + @score " +
                                    "WHERE mark_id = @id; " +
                                    "SELECT * FROM Marks WHERE mark_id = @id; " +
                                    "END";

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    SqlCommand command = new SqlCommand(procedureQuery, connection);
                    connection.Open();
                    command.ExecuteNonQuery();
                    MessageBox.Show($"Procedure '{procedureName}' created successfully.");
                }
            }
            catch (SqlException ex)
            {
                MessageBox.Show($"SQL Error occurred: {ex.Message}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while creating procedure '{procedureName}': {ex.Message}");
            }
        }

    }
}
