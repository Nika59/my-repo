<?php
    include "conn.php";
    $query_rec = "SELECT * FROM chefs";
    $result_rec = mysqli_query($conn, $query_rec);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body {
    font-family: 'Arial', sans-serif;
    margin: 0;
    padding: 0;
    box-sizing: border-box;
    color: #333;
}

header {
    background-color: #ff6347;
    padding: 10px 0;
}

nav {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}

.logo {
    font-size: 24px;
    font-weight: bold;
    color: #fff;
}

.nav-links {
    list-style: none;
    display: flex;
    gap: 20px;
}

.nav-links li a {
    color: #fff;
    text-decoration: none;
    font-size: 18px;
}

.auth-buttons {
    display: flex;
    gap: 15px;
}

.auth-buttons a {
    color: #fff;
    text-decoration: none;
    font-size: 18px;
    border: 1px solid #fff;
    padding: 5px 10px;
    border-radius: 5px;
}

.container {
    margin-top: 100px;
    height: 100vh;
  }

  .centered-div {
    border: 3px solid black;
    background-color: blanchedalmond;
    width: 100%;
    height: 800px;
    margin: auto;
  }

  .recipe_nav {
    border: 2px solid black;
    background-color: blanchedalmond;
    width: 200px;
    height: 800px;
  }

nav ul {
    padding: 0;
    margin: 0;
}

nav ul li {
    list-style: none;
}

nav ul li a {
    text-decoration: none;
    display: block;
    border-bottom: solid 1px gray;
    padding: 7px;
}

.recipe {
    position: absolute;
    left: 203px;
    top: 158px;
    width: 80%;
    height: 300px;
    border: 2px solid black;
    padding: 10px;
}

.recipe table {
    border-collapse: collapse;
    width: 100%;
}

.recipe table td, th {
    padding: 5px;
    border: 1px solid black;
}

.recipe .new_recipe{
    margin: 20px;
}
    </style>
</head>
<body>
    <header>
        <nav>
            <a href="#" class="logo">Culinary Portal</a>
            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#recipes">Recipes</a></li>
                <li><a href="#blog">Blog</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
            <div class="auth-buttons">
                <a href="signin.php" class="sign-in">Sign In</a>
                <a href="signup.php" class="sign-up">Sign Up</a>
            </div>
        </nav>
        
    </header>
    <div class="container">
        <div class="centered-div">
            <div class="recipe">
                <table class="data">
                    <tr>
                        <th>id</th>
                        <th>სახელი</th>
                        <th>შექმნა</th>
                        <th>განახლება</th>
                    </tr>
                    <?php
                        while ($data_rec = mysqli_fetch_assoc($result_rec)) {

                        
                    ?>
                    <tr>
                        <td><?=$data_rec["id"]?></td>
                        <td><?=$data_rec["chef_name"]?></td>
                        <td><?=$data_rec["createdAt"]?></td>
                        <td><?=$data_rec["updatedAt"]?></td>
                    </tr>
                    <?php
                        }
                    ?>
                </table>
            </div>
            <div class="recipe_nav">
            <nav style="min-height: 300px;">
                <ul>
                    <li><a href="recipes.php">რეცეპტების მართვა</a></li>
                    <li><a href="recipes.php">users</a></li>
                    <li><a href="chefs.php">შეფები</a></li>
                    <li><a href="meal_type.php">საკვების ტიპი</a></li>
                    <li><a href="reviews.php">განხილვა</a></li>
                </ul>
            </nav>
            </div>
        </div>
    </div>
</body>
</html>