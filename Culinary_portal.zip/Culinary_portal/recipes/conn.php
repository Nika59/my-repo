<?php

$serverName = "localhost";
$db = "root";
$dbPassword = "";
$dbName = "culinary_portal";

$conn = mysqli_connect($serverName, $db, $dbPassword, $dbName);
?>