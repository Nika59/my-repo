<?php
    include_once 'recipes/conn.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Document</title>
</head>
<body>
    <header>
        <nav>
            <a href="#" class="logo">Culinary Portal</a>
            <ul class="nav-links">
                <li><a href="#home">Home</a></li>
                <li><a href="#recipes">Recipes</a></li>
                <li><a href="#blog">Blog</a></li>
                <li><a href="#contact">Contact</a></li>
            </ul>
            <div class="auth-buttons">
                <a href="signin.php" class="sign-in">Sign In</a>
                <a href="signup.php" class="sign-up">Sign Up</a>
            </div>
        </nav>
        
    </header>
    <section id="home" class="hero">
        <div class="hero-content">
            <h1>Welcome to the Portal of Culinary Recipes</h1>
            <p>Your gateway to delicious and easy-to-follow recipes</p>
            <a href="#recipes" class="cta-button">Discover Recipes</a>
        </div>
    </section>
    <section id="recipes" class="recipes">
        <h2>Featured Recipes</h2>
        <div class="recipe-cards">
            <div class="recipe-card">
                <img src="images/images (1).jpg" alt="Recipe 1">
                <h3>Recipe Title 1</h3>
                <p>Short description of Recipe 1.</p>
                <a href="#" class="details-button">View Details</a>
            </div>
            <div class="recipe-card">
                <img src="images/images (2).jpg" alt="Recipe 2">
                <h3>Recipe Title 2</h3>
                <p>Short description of Recipe 2.</p>
                <a href="#" class="details-button">View Details</a>
            </div>
            <div class="recipe-card">
                <img src="images/images (3).jpg" alt="Recipe 3">
                <h3>Recipe Title 3</h3>
                <p>Short description of Recipe 3.</p>
                <a href="#" class="details-button">View Details</a>
            </div>
        </div>
    </section>
    <section id="contact" class="contact">
        <h2>Contact Us</h2>
        <form action="#">
            <label for="name">Name:</label>
            <input type="text" id="name" name="name" required>
            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>
            <label for="message">Message:</label>
            <textarea id="message" name="message" required></textarea>
            <button type="submit" class="submit-button">Send</button>
        </form>
    </section>
    <footer>
        <p>&copy; 2024 Portal of Culinary Recipes. All Rights Reserved.</p>
    </footer>
</body>
</html>