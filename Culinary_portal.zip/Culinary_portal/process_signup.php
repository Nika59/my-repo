<?php
include 'recipes/conn.php';

function is_password_strong($password) {
    $error = '';

    if (strlen($password) < 8) {
        $error .= "Password must be at least 8 characters long.<br>";
    }
    if (!preg_match('/[A-Z]/', $password)) {
        $error .= "Password must contain at least one uppercase letter.<br>";
    }
    if (!preg_match('/[a-z]/', $password)) {
        $error .= "Password must contain at least one lowercase letter.<br>";
    }
    if (!preg_match('/[0-9]/', $password)) {
        $error .= "Password must contain at least one digit.<br>";
    }
    if (!preg_match('/[\W]/', $password)) {
        $error .= "Password must contain at least one special character.<br>";
    }

    return $error ? $error : true;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if ($password !== $confirm_password) {
        echo "Passwords do not match. Please try again.";
    } else {
        $password_strength = is_password_strong($password);
        if ($password_strength !== true) {
            echo $password_strength;
        } else {
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                echo "Invalid email format. Please try again.";
            } else {
                $sql = "INSERT INTO users (email, password) VALUES (?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $email, $password);

                if ($stmt->execute()) {
                    header("Location: recipes/recipes.php");
                } else {
                    echo "There was an error during the sign-up process. Please try again.";
                }

                $stmt->close();
            }
        }
    }
} else {
    header("Location: signup.php");
    exit();
}

$conn->close();
?>
